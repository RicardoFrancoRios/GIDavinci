<?php
session_unset();
session_destroy();

header("location:inicio");
?>
<h1>Usted a salido exitosamente</h1>