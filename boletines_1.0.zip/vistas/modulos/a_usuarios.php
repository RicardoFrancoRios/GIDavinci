<?php
 if(!$_SESSION["session_iniciada"] || $_SESSION["session_iniciada"]==false){
 	header("location:inicio");
 	exit();
 }
?>
<h1 class="text-center"> Actualizar usuarios </h1>
<div class="container">
	<form method="post" class="form-signin" onsubmit=" return validar()">
	<p>

	<div class="row">
		<div class="input-field col s12">
			<select id="rol" name="rol" onchange="cambio()" required>
				<option selected value="0" disabled="selected"> Elija el nuevo rol</option>
		   		<?php
					$ingreso = new MvcControlador();
					$ingreso -> Roles_C2();
				?>
			</select>
		</div>
	</div>
	<br>
	<div id="datos">
			<div id="div_usuario" class="input-field col s6">
				<p>
				<label>Usuario:</label>
				<input type="text" name="usuario" id="usuario" value="<?= $usuario->usuario; ?>">
				<br>
			</div>

			<div id="div_password" class="input-field col s6">
				<p>
				<label>Password:</label>
				<input type="password" name="password" id="password" value="<?= $usuario->password; ?>"/>
				<br>
			</div>

			<div id="div_nombre" class="input-field col s6">
				<p>
				<label>Nombre:</label> 
				<input type ="text" name="nombre" id="nombre" value="<?= $usuario->nombre; ?>"/>
				<br>
			</div>

			<div id="div_apellido" class="input-field col s6">
				<p>
				<label>Apellido:</label>
				<input type ="text" name="apellido" id="apellido" value="<?= $usuario->apellido; ?>"/>
				<br>
			</div>

			<div id="div_ni" class="input-field col s6">
				<p>
				<label>Numero de identificación:</label>
				<input type="text" name="ni" id="ni" value="<?= $usuario->ni; ?>"/>
				<br>
			</div>
			
			<div id="div_acudiente" class="input-field col s6">
				<p>
				<label>Acudiente:</label>
				<input type="text" name="acudiente" id="acudiente" value="<?= $usuario->acudiente; ?>"/>
				<br>
			</div>

			<div id="div_telefono" class="input-field col s6">	
				<p>
				<label>Telefono:</label>
				<input type="text" name="telefono" id="telefono" value="<?= $usuario->telefono; ?>"/>
				<br>
			</div>
	<div class="row">
		<div class="input-field col s12">
			<div id="div_curso">
			<select id="curso" name="curso">
				<option selected value="0" disabled="selected"> Elija un curso</option>
   				<?php
					$ingreso = new MvcControlador();
					$ingreso -> ListaC_C();
				?>
			</select>
			</div>
		</div>
	</div>
	</div>

	<?php
	
	
	?>

	<button type="submit" class="btn btn-lg btn-primary btn-block" value="Registrar">Actualizar</button>	

	<?php
	$registro = new MvcControlador();
	$registro -> actualizarUsuarioControlador();
	?>	
	</form>

</div>