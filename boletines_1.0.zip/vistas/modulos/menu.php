<div class="lista_menu">
<nav class="nav-wrapper #4caf50 green customnavbar" role="navigation" id="nav-mobile" >
	<ul class="nav-wrapper nav-justified" id="nav-mobile" class="right hide-on-med-and-down">
		<?php
			$menu = new MvcControlador();
			$menu -> enlacesMenuControlador();
		?>
 		</ul>
	<a class="button-collapse" href="#" data-activates="nav-mobile">
	<i class="mdi-navigation-menu"></i></a> 		
</nav>
</div>