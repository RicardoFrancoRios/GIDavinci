<h1 class="text-center"> Página de Inicio</h1>
<br>
<p class="text-justif text-center">Bienvenido a este espacio interactivo creado con el fin de permitir a las personas que se encuentren vinculadas en el colegio, tener una interacción más cercana con los estudiantes.<p>