<?php
 if(!$_SESSION["session_iniciada"] || $_SESSION["session_iniciada"]==false){
 	header("location:inicio");
 	exit();
 }
?>
<h1 class="text-center"> Usuarios </h1>

<section id="lista_usuarios" name="lista_usuarios">

	<div class="table-responsive">

		<table class="table table-striped">

			<?php
			$v_usuarios = new MvcControlador();
			$v_usuarios -> listadoUsuariosControlador();
			?>

			<?php

			$borrar_actualizar = new MvcControlador();
			$borrar_actualizar -> borrarUsuarioControlador();
			?>
		</table>
	</div>
</section>

