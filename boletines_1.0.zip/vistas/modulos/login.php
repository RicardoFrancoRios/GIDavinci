<div class="container">

	<form method="post" class="form-signin" id="formLogin">
	<h2 class="text-center">Ingrese sus datos</h2>
	<br>
	<label for="inputText" class="sr-only">Usuario</label>
	<input type="text" id="usuario" name="usuario" class="form-control" placeholder="Usuario" required autofocus>
	<br>
	<label for="inputPassword" class="sr-only">Password</label>
	<input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
	<br>
	
	<div class="row">
		<div class="input-field col s12">
			<select id="rol" name="rol" required>
				<option selected value="0" disabled="selected"> Elige un rol </option>

		    	<?php
					$ingreso = new MvcControlador();
					$ingreso -> Roles_C();
				?>
   	

			</select>
		</div>
	</div>
	<br>

	<a href="password">¿Olvido su clave?</a>

	<br>
	<br>
	<?php
		$ingreso = new Ingreso_C();
		$ingreso -> ingresoUsuariosControlador();
	?>

	<button id="botonEnviar" class="btn btn-lg btn-primary btn-block" type="submit">Ingresar</button>
	</form>

</div>






	

