<?php
 if(!$_SESSION["session_iniciada"] || $_SESSION["session_iniciada"]==false){
 	header("location:inicio");
 	exit();
 }
?>