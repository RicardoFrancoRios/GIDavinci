<?php
 if(!$_SESSION["session_iniciada"] || $_SESSION["session_iniciada"]==false){
 	header("location:inicio");
 	exit();
 }
else{
 	$us=$_SESSION["usuario"];
 	$usuario = Datos::usuarioModelo($us);
	echo("<h1 class='text-center'> Bienvenid@ estudiante". $usuario[0]["us_nombre"] ."</h1>");
}
?>
