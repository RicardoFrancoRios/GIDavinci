<?php
 if(!$_SESSION["session_iniciada"] || $_SESSION["session_iniciada"]==false){
 	header("location:inicio");
 	exit();
 }
?>
<header>	
	<h1 class="text-center">Registro de notas</h1>
</header>
<div class="container">

	<form method="post" class="form-signin">
	<p>

	<div class="row">

		<div id="div_curso" class="input-field col s6">
			<select id="curso" name="curso" onchange="escu()" required>
				<option selected value="0" disabled="selected"> Elija el curso</option>

				<?php
					$ingreso = new MvcControlador();
					$ingreso -> ListaC_C1();
				?>
		   		
			</select>
		</div>

		<div id="div_periodo" class="input-field col s6">
			<select id="periodo" name="periodo" onchange="espe()" required>
				<option selected value="0" disabled="selected"> Elija el periodo a evaluar</option>
				<?php
					$ingreso = new MvcControlador();
					$ingreso -> ListaP_C1();
				?>
				
			</select>
		</div>
	</div>
</div>
<div id="div_lnotas">
	<section id="lista_usuarios" name="lista_usuarios">
		<div class="table-responsive">
			<table class="table table-striped centered bordered">
					<?php
					$v_usuarios = new MvcControlador();
					$v_usuarios -> listadoNotasControlador();
					?>
			</table>
		</div>
	</section>
</div>
<button id=RNBoton type="submit" class="waves-effect waves-light btn-large" value="RegistrarNotas">Registrar Notas<i class="material-icons right">send</i></button>	