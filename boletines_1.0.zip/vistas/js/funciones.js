function cambio(){
$escoger = $("#rol").val()*1;
console.log($escoger);
/*administrador*/
if ($escoger == 1){
	$("#div_usuario").show();
	$("#div_password").show();
	$("#div_nombre").show();
	$("#div_apellido").show();
	$("#div_ni").show();
	$("#div_curso").hide();
	$("#div_acudiente").hide();
	$("#div_telefono").show();
	$("#div_rolPHP").hide();
}
/*directivos*/
else if ($escoger == 2){
	$("#div_usuario").show();
	$("#div_password").show();
	$("#div_nombre").show();
	$("#div_apellido").show();
	$("#div_ni").show();
	$("#div_curso").hide();
	$("#div_acudiente").hide();
	$("#div_telefono").show();
	$("#div_rolPHP").hide();
}
/*docentes*/
else if ($escoger == 3){
	$("#div_usuario").show();
	$("#div_password").show();
	$("#div_nombre").show();
	$("#div_apellido").show();
	$("#div_ni").show();
	$("#div_acudiente").hide();
	$("#div_curso").show();
	$("#div_telefono").show();
	$("#div_rolPHP").hide();
}
/*estudiantes*/
else if ($escoger == 4){
	$("#div_usuario").show();
	$("#div_password").show();
	$("#div_nombre").show();
	$("#div_apellido").show();
	$("#div_ni").show();
	$("#div_acudiente").show();
	$("#div_curso").show();
	$("#div_telefono").show();
	$("#div_rolPHP").hide();
}
else if ($escoger == 0) {
	$("#div_usuario").hide();
	$("#div_password").hide();
	$("#div_nombre").hide();
	$("#div_apellido").hide();
	$("#div_ni").hide();
	$("#div_curso").hide();
	$("#div_acudiente").hide();
	$("#div_telefono").hide();
	$("#div_rolPHP").hide();
}

}

function cargar(){
	$().button('toggle');
	cambio();
	$("#div_periodo").hide();
	$("#div_lnotas").hide();
	$("#RNBoton").hide();
}

function escu(){
	$("#div_periodo").show();
}

function espe(){
    $("#div_lnotas").show();
    $("#RNBoton").show();
}




