<?php
session_start();
if(!$_SESSION["session_iniciada"]=true){
	header("location:login");
	exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title></title>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<script type="text/javascript" src="vistas/js/funciones.js"></script>
	<script type="text/javascript" src="vistas/js/jquery-3.2.0.js"></script>
	<script type="text/javascript" src="vistas/js/Bootstrap.js"></script>
	<script type="text/javascript" src="vistas/js/Bootstrap2-toggle.js"></script>
	<script type="text/javascript" src="vistas/js/materialize.js"></script>
	<script type="text/javascript" src="vistas/js/materialize.min.js"></script>


	<link rel="stylesheet" href="vistas/css/Bootstrap.css">
	<link rel="stylesheet" href="vistas/css/Bootstrap2-toggle.css">
	<link rel="stylesheet" href="vistas/css/bootstrapmin.css">
	<link rel="stylesheet" href="vistas/css/main.css">
	<link rel="stylesheet" href="vistas/css/materialize.css">
	<link rel="stylesheet" href="vistas/css/materialize.css">	
</head>
<body id="cuerpo" onload="cargar()">

<header>
	<div align="center"><img src="vistas/imagenes/escudo.png"></div>	
</header>

<?php 
include "modulos/menu.php";
 ?>
 
<section>
	<?php 
		$mvc = new MvcControlador();
		$mvc -> enlacesPaginasControlador();
	?>
</section>

<script >
	$(document).ready(function(){
		$('select').material_select();
	})
</script>
</body>
</html>