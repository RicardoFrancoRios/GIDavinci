<?php 

require_once "conexion.php";

class Datos extends Conexion{

		public function Roles_Modelo(){
			$c_bd = Conexion::conectar() -> prepare("SELECT * FROM tb_roles");
			$c_bd ->execute();
			return $c_bd -> fetchAll();
			$c_bd -> close();

		}

		public function Cursos_Modelo(){
			$c_bd = Conexion::conectar() -> prepare("SELECT * FROM tb_cursos");
			$c_bd ->execute();
			return $c_bd -> fetchAll();
			$c_bd -> close();

		}

		public function Cursod_Modelo($us){
			$c_bd = Conexion::conectar() -> prepare("SELECT us_idCursoFk FROM tb_usuarios where '$us' = us_usuario");
			$c_bd ->execute();
			return $c_bd -> fetch();
			$c_bd -> close();
		}

		public function Periodo_Modelo(){
			$c_bd = Conexion::conectar() -> prepare("SELECT * FROM tb_periodos where pe_estado = 1 ");
			$c_bd -> execute();
			return $c_bd ->fetch();
			$c_bd -> close();
		}

		public function borrarUsuarioModelo($id_usuario_a_borrar){
			$c_bd = Conexion::conectar() -> prepare("DELETE FROM tb_usuarios where :id_usuario_a_borrar = us_idUsuario");
			$c_bd -> bindParam (":id_usuario_a_borrar",$id_usuario_a_borrar,PDO::PARAM_INT);

			if($c_bd -> execute()){
				return "borrado_exitoso";
			}
			else{
				return "error";
			}
			$c_bd -> close();
		}

		public function registroUsuariosModelo($datosModelo){

			$c_bd = Conexion::conectar()->prepare("INSERT INTO tb_usuarios (us_usuario,us_password,us_nombre, us_apellido,us_ni,us_telefono,us_acudiente,us_idRolFk,us_idCursoFk) values(:usuario,:password,:nombre,:apellido,:ni,:telefono,:acudiente,:rol,:curso)");

		$c_bd -> bindParam(":usuario",$datosModelo["usuario"],PDO::PARAM_STR);
		$c_bd -> bindParam(":password",$datosModelo["password"],PDO::PARAM_STR);
		$c_bd -> bindParam(":nombre",$datosModelo["nombre"],PDO::PARAM_STR);
		$c_bd -> bindParam(":apellido",$datosModelo["apellido"],PDO::PARAM_STR);
		$c_bd -> bindParam(":ni",$datosModelo["ni"],PDO::PARAM_INT);
		$c_bd -> bindParam(":telefono",$datosModelo["telefono"],PDO::PARAM_STR);
		$c_bd -> bindParam(":acudiente",$datosModelo["acudiente"],PDO::PARAM_STR);
		$c_bd -> bindParam(":rol",$datosModelo["rol"],PDO::PARAM_INT);
		$c_bd -> bindParam(":curso",$datosModelo["curso"],PDO::PARAM_INT);


		if ($c_bd ->execute()) {
			return "registro Exitoso";
		}
		else{
			return "error";
		}

		$c_bd -> close();
		}

		public function listadoUsuariosModelo(){
			$c_bd = Conexion::conectar() -> prepare("SELECT * FROM tb_usuarios ORDER BY us_idCursoFk,us_idRolFk,us_apellido");
			$c_bd -> execute();
			return $c_bd -> fetchAll();
			$c_bd -> close();
		}

		public function rolesModelo(){
			$c_bd = Conexion::conectar() -> prepare("SELECT * FROM tb_roles");
			$c_bd ->execute();
			return $c_bd -> fetchAll();
			$c_bd -> close();
		}

		public function cursosModelo(){
			$c_bd = Conexion::conectar() -> prepare("SELECT * FROM tb_cursos");
			$c_bd ->execute();
			return $c_bd -> fetchAll();
			$c_bd -> close();
		}

		public function usuarioModelo($us){
			$c_bd = Conexion::conectar() -> prepare("SELECT us_nombre FROM tb_usuarios where '$us' = us_usuario");
			$c_bd ->execute();
			return $c_bd -> fetchAll();
			$c_bd -> close();
		}

		public function logrosModelo(){
			$c_bd = Conexion::conectar()->prepare("SELECT * FROM tb_logros");
			$c_bd ->execute();
			return $c_bd -> fetchAll();
			$c_bd -> close();
		}

		public function notasModelo(){
			$c_bd = Conexion::conectar()->prepare("SELECT * FROM tb_notas");
			$c_bd ->execute();
			return $c_bd -> fetchAll();
			$c_bd -> close();
		}
		public function materiasModelo(){
			$c_bd = Conexion::conectar()->prepare("SELECT * FROM tb_materias");
			$c_bd ->execute();
			return $c_bd -> fetchAll();
			$c_bd -> close();
		}

		public function cantidadLogrosModelo(){
			$c_bd = Conexion::conectar()->prepare("SELECT COUNT(lo_idLogro) FROM tb_logros");
			$c_bd ->execute();
			return $c_bd -> fetch();
			$c_bd -> close();
		}
}
?>