 <?php 

class MvcModelo{

	public function enlacesMenuModelo(){
		if(isset($_SESSION["session_iniciada"])&&
		   isset($_SESSION["usuario"])&&
		   isset($_SESSION["password"])&&
		   isset($_SESSION["rol"])){
			if($_SESSION["session_iniciada"]==true){
				//administrador
				if($_SESSION["rol"]==1){
					$enlaces=array("inicio","r_usuarios","v_usuarios","salir");
				}
				//directivo
				else if($_SESSION["rol"]==2){
					$enlaces=array("inicio","r_usuarios","v_usuarios","e_boletin","salir");
				}
				//docente
				else if($_SESSION["rol"]==3){
					$enlaces=array("inicio","r_notas","v_usuarios","e_boletin","salir");
				}
				//estudiante
				else{
					$enlaces=array("inicio","e_boletin","salir");
				}
			}
		}
		else{
			$enlaces = array("inicio","login");
		}
		return $enlaces;
	}

	public function enlacesPaginasModelo($enlace){

		$modulo = "vistas/modulos/";

		$enlaces = array("administrador","directivo","estudiantes","inicio","login","menu","notas","profesores","r_notas","r_usuarios","v_usuarios","e_boletin","salir","password");

		if (in_array($enlace, $enlaces)){

			$modulo = $modulo.$enlace.".php";

		}
		else{
			$modulo = $modulo."inicio.php";
		}


		return $modulo;

	}
}

?>