<?php 

require_once "conexion.php";

class Ingreso_M{
	public function ingresoModelo($datosModelo){

		$c_bd = Conexion::conectar()->prepare("SELECT us_usuario, us_password, us_idRolFk, us_idCursoFk FROM tb_usuarios WHERE us_usuario =:usuario and us_password = :password and us_idRolFk = :rol");

		$c_bd -> bindParam(":usuario",strtoupper($datosModelo["usuario"]),PDO::PARAM_STR);
		$c_bd -> bindParam(":password",$datosModelo["password"],PDO::PARAM_STR);
		$c_bd -> bindParam(":rol",$datosModelo["rol"],PDO::PARAM_INT);


		$c_bd -> execute();

		return $c_bd ->fetch();

		$c_bd -> close();
	}
}
?>