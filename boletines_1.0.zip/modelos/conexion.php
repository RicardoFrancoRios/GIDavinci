<?php

class Conexion{
	
	public function conectar(){
		
		$conn = new PDO("mysql:host=localhost; dbname=garden", "root","");

		return $conn;
	}
}
?>