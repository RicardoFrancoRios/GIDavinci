<?php
class Ingreso_C{

	public function ingresoUsuariosControlador(){
		if(isset($_POST["usuario"])&& isset($_POST["password"]) && isset($_POST["rol"])){
			
			$datosControlador = array("usuario"=>$_POST["usuario"], "password"=>$_POST["password"], "rol"=>$_POST["rol"]);

			$respuesta = Ingreso_M::ingresoModelo($datosControlador);



			if ($respuesta["us_usuario"]==$_POST["usuario"] && 
				$respuesta["us_password"]==$_POST["password"] &&
				$respuesta["us_idRolFk"]==($_POST["rol"])){

				echo ("<div class='alert alert-sucess'> <strong>¡Excelente!</strong> A ingresado correctamente. </div>");

				$_SESSION["session_iniciada"]=true;
				$_SESSION["usuario"]=$respuesta["us_usuario"];
				$_SESSION["password"]=$respuesta["us_password"];
				$_SESSION["rol"]=$respuesta["us_idRolFk"];
				$_SESSION["curso"]=$respuesta["us_idCursoFk"];

				echo ("Ingreso correcto");
				
				if($respuesta["us_idRolFk"]==1){
				
					header("location:administrador");
				}

				elseif ($respuesta["us_idRolFk"]==2){

					header("location:directivo");
				}

				elseif ($respuesta["us_idRolFk"]==3) {
					header("location:profesores");
				}

				elseif ($respuesta["us_idRolFk"]==4){
					header("location:estudiantes");
				}
				
			}
			else{

				echo ("<div class='alert alert-danger'> <strong>¡ERROR!</strong> usuario y/o contraseña errada. </div>");
				
			}
		}

	}
}
?>