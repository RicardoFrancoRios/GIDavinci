<?php 

/*
[] creamos la plantilla (clase) MvcControlador
[] creamos una funcion que nos llamara a la plantilla
[] por medio de la función llamamos al archivo plantilla de la vista
*/

class MvcControlador{

	public function Roles_C(){
		$roles = Datos::Roles_Modelo();


		foreach ($roles as $rol){

			echo("<option value= ". $rol["ro_idRol"]." >".$rol["ro_nombre"]."</option> ");	

		}
	}

	public function ListaC_C(){
		$cursos = Datos::Cursos_Modelo();

		foreach ($cursos as $curso){
			
			echo("<option value= ". $curso["cu_idCurso"]." >".$curso["cu_nombre"]."</option> ");
		}
	}

	public function ListaC_C1(){
		if(isset($_SESSION["usuario"])){
		
		$us=$_SESSION["usuario"];
		
		$cursod= Datos::Cursod_Modelo($us);
		$cursos = Datos::Cursos_Modelo();

		$c = $cursod["us_idCursoFk"];
		foreach ($cursos as $curso) {
			if($curso["cu_idCurso"]==$c){
				echo("<option value= ".$c." >".$curso["cu_nombre"]."</option> ");
			}
			
		}
		}
	}

	public function ListaP_C1(){
		$periodos = Datos::Periodo_Modelo();
		
		echo("<option value= ".$periodos["pe_idPeriodo"]." >".$periodos["pe_nombre"]."</option> ");
		
	}

	public function Roles_C1(){
		$roles = Datos::Roles_Modelo();

		if(isset($_SESSION["rol"])){

			switch ($_SESSION["rol"]) {
				case '1':
					echo("<option value= ". $roles [0]["ro_idRol"].">" .$roles[0]["ro_nombre"]."</option> ");
					echo("<option value= ". $roles [1]["ro_idRol"].">" .$roles[1]["ro_nombre"]."</option> ");
					break;

				case '2':
					echo("<option value= ". $roles [2]["ro_idRol"].">" .$roles[2]["ro_nombre"]."</option> ");
					echo("<option value= ". $roles [3]["ro_idRol"].">" .$roles[3]["ro_nombre"]."</option> ");
					break;

					break;
			}
		}
	}

	public function Cursos_C(){
		$roles = Datos::Roles_Modelo();


		foreach ($roles as $rol){

			echo("<option value= ". $rol["ro_idRol"]." >".$rol["ro_nombre"]."</option> ");	

		}
	}

	public function borrarUsuarioControlador(){

		if(isset($GET["borrar_id"])){
			$id_usuario_a_borrar = $GET["borrar_id"];
			echo($id_usuario_a_borrar);
			$respuesta = Datos::borrarUsuarioModelo($id_usuario_a_borrar);

			if($respuesta=="borrado_exitoso"){

				ob_start();
				header("location:v_usuarios");
				echo "Exito";
			}

			else if($respuesta=="error"){
				header("location:v_usuarios");
				echo "Error, no se pudo borrar el usuario";
			}
		}
	}

	public function listadoUsuariosControlador(){
		$usuarios = Datos::listadoUsuariosModelo();
		$roles=Datos::rolesModelo();
		$cursos=Datos::cursosModelo();
		$contador=0;
	if(isset($_SESSION["rol"])){

		echo"<tr>
				<th>#</th>
				<th>Usuario</th>
				<th>Nombre</th>
				<th>Apellido</th>
				<th>NI</th>
				<th>Cargo</th>";

		if($_SESSION["rol"]==1){
			echo"
				<th>Editar</th>
				<th>Eliminar</th>";
		}
		else if($_SESSION["rol"]==2){
			echo"
				<th>Curso asignado</th>
				<th>Acudiente</th>
				<th>Editar</th>
				<th>Eliminar</th>";
		}
		else if($_SESSION["rol"]==3){
			echo"
				<th>Curso asignado</th>
				<th>Acudiente</th>";
		}
		else{

		}

		echo "</tr>";

		foreach ($usuarios as $usuario){

			$contador++;
			$_r = 1;

			if($_SESSION["rol"]== 1 && ($usuario["us_idRolFk"]==1 || $usuario["us_idRolFk"]==2)){


				echo"<tr>";
				echo"<td>".$contador."</td>";

				/*echo "<td><input type='text' placeholder".$usuario["us_usuario"]
														 ."name=".$usuario["us_idUsuario"]."_usuario"
														 ."id=".$usuario["us_idUsuario"]."_usuario"
														 ."required class='form-control'"
														 ."value=".$usuario["us_usuario"]
														 ."disabled> </td>";*/

				echo"<td>".$usuario["us_usuario"]."</td>";
				echo"<td>".$usuario["us_nombre"]."</td>";
				echo"<td>".$usuario["us_apellido"]."</td>";
				echo"<td>".$usuario["us_ni"]."</td>";

				$rol = $usuario["us_idRolFk"];
				echo"<td>".$roles[$rol-1][$_r]."</td>";
			}
			else if($_SESSION["rol"]== 2 && ($usuario["us_idRolFk"]==3 || $usuario["us_idRolFk"]==4)){

				

				echo"<tr>";
				echo"<td>".$contador."</td>";

				echo"<td>".$usuario["us_usuario"]."</td>";
				echo"<td>".$usuario["us_nombre"]."</td>";
				echo"<td>".$usuario["us_apellido"]."</td>";
				echo"<td>".$usuario["us_ni"]."</td>";
				
				$rol = $usuario["us_idRolFk"];
				echo"<td>".$roles[$rol-1][$_r]."</td>";

				$curso = $usuario["us_idCursoFk"];
				echo"<td>".$cursos[$curso-1][$_r]."</td>";

				echo "<td>".$usuario["us_acudiente"]."</td>";
				
			}

			else if (isset($_SESSION["curso"])){ 
				if($_SESSION["rol"]== 3 && ($usuario["us_idRolFk"]==4 && $usuario["us_idCursoFk"] == $_SESSION["curso"])){

				echo"<tr>";
				echo"<td>".$contador."</td>";

				echo"<td>".$usuario["us_usuario"]."</td>";
				echo"<td>".$usuario["us_nombre"]."</td>";
				echo"<td>".$usuario["us_apellido"]."</td>";
				echo"<td>".$usuario["us_ni"]."</td>";

				$rol = $usuario["us_idRolFk"];
				echo"<td>".$roles[$rol -1][$_r]."</td>";

				$curso = $usuario["us_idCursoFk"];
				echo"<td>".$cursos[$curso -1][$_r]."</td>";

				echo "<td>".$usuario["us_acudiente"]."</td>";
			}
			}

			if($_SESSION["rol"]== 1 && ($usuario["us_idRolFk"]==1 || $usuario["us_idRolFk"]==2)){

				echo'<td>

					<input type="checkbox"
											data-toggle="toggle"
											data-size="large"
											data-onstyle="success"
											data-offstyle="default"
											data-on="Editar"
											data-off=" "
											data-width="100"
											data-height="30"
											id="'.$usuario["us_idUsuario"].'"name="'.$usuario["us_usuario"].'"></td>';
				echo "<td>
						<a href='index.php?borrar_id=".$usuario['us_idUsuario']."'><button type='button' class='btn btn-danger'>X</button></a>
					 </td>";
			}
			else if($_SESSION["rol"]== 2 && ($usuario["us_idRolFk"]==3 || $usuario["us_idRolFk"]==4)){

				echo'<td>

					<input type="checkbox"
											data-toggle="toggle"
											data-size="large"
											data-onstyle="success"
											data-offstyle="default"
											data-on="Editar"
											data-off=" "
											data-width="100"
											data-height="30"
											id="'.$usuario["us_idUsuario"].'"name="'.$usuario["us_usuario"].'"></td>';
				echo "<td>
						<a href='index.php?borrar_id=".$usuario['us_idUsuario']."'><button type='button' class='btn btn-danger'>X</button></a>
					 </td>";

			}

			echo"</tr>";

		}

			if($_SESSION["rol"]==1 || $_SESSION["rol"]==2){
				echo"<tr>
					<th> </th>
					<th> </th>
					<th> </th>
					<th> </th>
					<th> </th>
					<th> </th>
					<th> </th>
					<th> </th>";
				echo '<th><button type="button" class="btn btn-sucess btn-lg"> Editar </th>';
				echo "<th> </th>
					</tr>";	
			}

		else{
			
		}

	}
	}

		public function listadoNotasControlador(){
		$usuarios = Datos::listadoUsuariosModelo();
		$roles=Datos::rolesModelo();
		$cursos=Datos::cursosModelo();
		$logros=Datos::logrosModelo();
		$notas=Datos::notasModelo();
		$materias = Datos::materiasModelo();
		$l = Datos::cantidadLogrosModelo();
		$contador=0;
		$r = 0;
		$_r = 1;

		if(isset($_SESSION["rol"])){


			echo"<thead>
					<tr>
					<th>#</th>
					<th>Nombre</th>
					<th>Apellido</th>
					<th colspan='8' class='centered'>Materias/Logros</th>
					</tr>
				</thead>";

			echo"<thead>
					<tr>
					<th></th>
					<th></th>
					<th></th>
					<th colspan='2'>Kinestecica</th>
					<th colspan='2'>Linguistica</th>
					<th colspan='2'>Sistemas</th>
					<th colspan='2'>Ingles</th>				
					<th></th>
					<th></th>
					</tr>
				</thead>";

			echo "</thead>
					<tr>
					<th></th>
					<th></th>
					<th></th>";
					foreach ($logros as $logro) {	
					echo"<th>".$logro["lo_nombre"]."</th>";
				}
			echo "	</tr>
				</thead>";

			foreach ($usuarios as $usuario){

				$contador++;
				$_r = 1;

				if (isset($_SESSION["curso"])){ 
					if($_SESSION["rol"]== 3 && ($usuario["us_idRolFk"]==4 && $usuario["us_idCursoFk"] == $_SESSION["curso"])){
						echo "<thead>
						<tr>
						<td>".$contador."</td>
						<td>".$usuario["us_nombre"]."</td>
						<td>".$usuario["us_apellido"]."</td>";

						foreach ($l as $v) {
							$s = $v["lo_idLogro"];
							for ($i=0; $i < $s-$s/2; $i++) { 
								echo "<div class='select_notas'>";
								echo "<td><select  id='notas' name='notas' required>";
									foreach ($notas as $nota) {
										echo"<option value= ". $nota["no_idNota"]." >".$nota["no_nombre"]."</option>";
									}
								echo "</select></td>";
								echo "</div>";
							}
						}
						echo "</tr>
						</thead>";
					}
				}
			}
		}
	}	

	public function enlacesMenuControlador(){
		$enlaces = MvcModelo::enlacesMenuModelo();
		foreach($enlaces as $enlace){

			if($enlace=="inicio"){
				$nenlace = "Inicio".'<i class="material-icons left">home</i>';
			}
			else if($enlace=="login"){
				$nenlace = "Login".'<i class="material-icons right">vpn_key</i>';
			}
			else if($enlace=="r_usuarios"){
				$nenlace = "Registrar".'<i class="material-icons right">mode_edit</i>' ;
			}
			else if($enlace=="v_usuarios"){

				if(isset($_SESSION["rol"])){
					if($_SESSION["rol"]<>3){
					$nenlace = "Visualizar usuarios".'<i class="material-icons right">perm_identity</i>' ;
					}
					else{
					$nenlace = "Visualizar estudiantes".'<i class="material-icons right">perm_identity</i>';
					}
				}
			}
			else if($enlace=="e_boletin"){
				$nenlace = "Mirar boletin".'<i class="material-icons right">assignment</i>';
			}
			else if($enlace=="r_notas"){
				$nenlace = "Registro notas".'<i class="material-icons right">mode_edit</i>';
			}
			else if($enlace=="salir"){
				$us=$_SESSION["usuario"];
 				$usuario = Datos::usuarioModelo($us);
				$nenlace = $usuario[0]["us_nombre"].'<i class="material-icons right">lock_outline</i>';
			}
			echo '<li><a href="'.$enlace.'">'.$nenlace.'</a></li>';

		}
	}

	#--------------------------------------#
	#------llamamos a la plantilla---------#
	#--------------------------------------#

	public function plantilla(){
		include "vistas/plantilla.php";

	}

	public function rolesControlador(){

		$respuesta = Datos::rolesModelo();

		echo('<select placeholder="rol" name="rol" id="rol" required>');

		foreach ($respuesta as $row) {
			echo('<option value=""'.$row["ro_idRol"].'">'.$row["ro_nombre"].'</option>');
		}

		echo('</select>');
	}

	#--------------------------------------#
	#--------enlaces a las paginas---------#
	#--------------------------------------#
	public function enlacesPaginasControlador(){
		
		
		/*
		[] verificamos si se ha enviado la variable llamar usando GET
		[] en caso de existir en envio, guardamos en valor en $enlace
		[] en caso de no existir el envio, decimos que $enlace = "inicio"
		*/
		$enlace="inicio";


		if(isset($_GET["llamar"])){
			$enlace = $_GET["llamar"];
		}
		else if (isset($_GET["borrar_id"])){
			$enlace = "v_usuarios";
		}
		else{
			$enlace="inicio";
		}

		/*
		vamos a acceder a una de las posibles vistas de los modulos
		[] creamos la variable $modulo
		[] heredamos la clase del modelo
		[] conectamos la clase del modelo y el método para llamar el enlace
		[] actualizamos la vista, incluyendo el $modulo que nos envia el modelo
		*/

		#heredar la clase y el metodo
		$modulo = MvcModelo::enlacesPaginasModelo($enlace);

		include $modulo;
	}

	#--------------------------------------#
	#--------registro usuarios-------------#
	#--------------------------------------#

	public function registroUsuariosControlador(){

			if( isset($_POST["usuario"]) &&isset($_POST["password"]) &&isset($_POST["nombre"]) && isset($_POST["apellido"]) && isset($_POST["ni"]) && isset($_POST["acudiente"])&&isset($_POST["curso"]) && isset($_POST["telefono"]) && isset($_POST["rol"])){

				$datosControlador = array("usuario"=>$_POST["usuario"],
										  "password"=>$_POST["password"],
										  "nombre" =>$_POST["nombre"],
										  "apellido" =>$_POST["apellido"],
										  "ni" =>$_POST["ni"], 
										  "acudiente"=>$_POST["acudiente"],
										  "curso"=>$_POST["curso"],
										  "telefono" =>$_POST["telefono"],
										  "rol"=>$_POST["rol"]);
	
				$respuesta = Datos::registroUsuariosModelo($datosControlador);

				if($respuesta=="registro Exitoso"){
					echo("Registro Exitoso");
				}
				else{
					echo ("Registro Incorrecto");
				}				
			}
			else if (isset($_POST["usuario"]) &&isset($_POST["password"]) &&isset($_POST["nombre"]) && isset($_POST["apellido"]) && isset($_POST["ni"]) && isset($_POST["telefono"]) && isset($_POST["rol"])){

				$datosControlador = array("usuario"=>$_POST["usuario"],
										  "password"=>$_POST["password"],
										  "nombre" =>$_POST["nombre"],
										  "apellido" =>$_POST["apellido"],
										  "ni" =>$_POST["ni"], 
										  "telefono" =>$_POST["telefono"],
										  "rol"=>$_POST["rol"]);
	
				$respuesta = Datos::registroUsuariosModelo($datosControlador);

				if($respuesta=="registro Exitoso"){
					echo("Registro Exitoso");
				}
				else{
					echo ("Registro Incorrecto");
				}				
			}
		}
}
?>