<?php 

/*
[] requeriremos una sola ves los controladores y modelos.
*/


/*
* instanciamos el archivo controlador SOLO 1 vez
* creamos un objeto a partir de la clase controlador
* luego llamamos la funcion plantilla de ese objeto
*/
require_once "controladores/controlador.php";
require_once "modelos/modelo.php";

require_once "controladores/ingreso_controlador.php";
require_once "modelos/ingreso_modelo.php";

require_once "modelos/crud.php";

$mvc = new MvcControlador();
$mvc -> plantilla();


?>

